<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class affiliate_bank_account extends Model
{
    //
}
